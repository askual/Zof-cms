
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        askual
    </title>
    <link rel="icon" 
      type="image/png" 
      href="https://askual.com/logo.ico">
      <meta name="google-site-verification" content="yknFsWakLQNKP4Q6i_4fSeWiohWCF0HwYYNY6ZDvTn0" />
      

    <link rel="stylesheet" type="text/css" href="{{url('css/font-awesome.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{url('css/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{url('css/hover.css')}}">
    <link rel="stylesheet" type="text/css" href="{{url('css/bootstrap.min.css')}}">
    <!-- <link type="text/css" rel="stylesheet" href="//unpkg.com/bootstrap/dist/css/bootstrap.min.css"/> -->
    <link type="text/css" rel="stylesheet" href="//unpkg.com/bootstrap-vue@latest/dist/bootstrap-vue.css"/>
        <script src="https://cdn.jsdelivr.net/npm/vue@2.5.17/dist/vue.js"></script>
    <!-- Add this after vue.js -->
    <script src="//unpkg.com/babel-polyfill@latest/dist/polyfill.min.js"></script>
    <script src="//unpkg.com/bootstrap-vue@latest/dist/bootstrap-vue.js"></script>

    @yield('meta')
    @yield('css')
</head>
<body>
    <div class="container-fluid contMy wrapper">
        <nav class="navbar navbar-default navbar-expand-lg navbar-dark">
            <div class="container">
                <a class="navbar-brand" href="{{route('news.index')}}">
                    <img src="{{url('img/askual-logo.svg')}}" width="30" height="30" class="d-inline-block align-top" alt=""> ASKUAL NEWS
                </a>
                <!-- <span class="navbar-text">
                            The digital getway for Ethiopia
                        </span> -->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li id="home" class="nav-item">
                            <a class="nav-link" href="@{{route('index')}}">Home</a>
                        </li>
                        <li id="link" class="nav-item">
                            <a class="nav-link" href="@{{route('link')}}">News</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            @yield('content')
        </div>

        <div class="footer bg-my" id="footer">
            <div class="container">
                <ul class="nav justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link" target="_blank" href="https://twitter.com/askual-tech"><i class="fa fa-twitter fa-fw"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" target="_blank" href="https://facebook.com/askual-tech"><i class="fa fa-facebook fa-fw"></i></a>
                    </li>
                    <li class="nav-item"><!-- 
                        <a class="nav-link" href="#"><i class="fa fa-google-plus fa-fw"></i></a>
                    </li> -->
                    <li class="nav-item">
                        <a class="nav-link" target="_blank" href="https://www.youtube.com/channel/UCH1Ikxnm6RrnH7dUbHG50qQ"><i class="fa fa-youtube fa-fw"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" target="_blank" href="https://linkedin.com/askual-tech"><i class="fa fa-linkedin fa-fw"></i></a>
                    </li>

                </ul>
                <ul class="nav justify-content-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="@{{route('index')}}">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="@{{route('privacy')}}">Privacy Policy</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="@{{route('contact')}}">Contact Us</a>
                    </li>
                </ul>
                <p class="copyright" style="color: #fff">
                    Copyright &copy; 2018 Askual.com. All rights reserved.</a>
                </p>
            </div>
        </div>
    </div>
    
    <!-- jQuery -->
    <!-- <script src="{{url('js/jquery.js')}}"></script> -->
    <!-- Bootstrap Core JavaScript -->
    <!-- <script src="{{url('js/bootstrap.min.js')}}"></script> -->


    @yield('js')
</body>
</html>