<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Http\Request;
$appRoutes = function()  {
	Route::get('/',function(){
	    return "qqq";
	})->name('quiz.index');
};

Route::get('/abcd', 'QuizController@abcd');



Route::group(array('domain' => 'quiz.askual.com'), $appRoutes);
Route::group(array('domain' => 'www.quiz.askual.com'), $appRoutes);


// Route::prefix('quiz')->group(function() {
    // Route::get('/', 'QuizController@index')->name('quiz');
    // Route::get('/q/{slug}', 'QuizController@single_post')->name('single_post');
// });
Route::group(['prefix'=>'admin/quiz' ], function () {
    Route::get('/all', 'AdminController@quiz')->name('admin.quiz.index');
    Route::get('/new', 'AdminController@new_quiz')->name('admin.quiz.new');
    // Route::get('/users', 'AdminController@users')->name('admin.users');
    // Route::get('/quiz/list', 'QuizController@index')->name('admin.quiz.list');
    // Route::get('/quiz/add', 'QuizController@create')->name('admin.quiz.add');
    // Route::post('/quiz/update', 'QuizController@update')->name('admin.quiz.update');
    // Route::post('/quiz/store', 'QuizController@store')->name('admin.quiz.store');
    // Route::get('/quiz/choice/add/{id}', 'ChoiceController@create')->name('admin.choice.add');
    // Route::post('/quiz/choice', 'ChoiceController@store')->name('admin.choice.store');
    // Route::post('/quiz/append', 'ChoiceController@append')->name('admin.choice.append');
    // Route::get('/quiz/choice/delete/{id}', 'ChoiceController@delete')->name('admin.choice.delete');
    // Route::post('/quiz/tag', 'QuizController@tag')->name('admin.quiz.tag');

    // Route::get('/quiz/active/toggle/{id}', 'QuizController@active_toogle')->name('admin.quiz.active_toggle');
    // Route::get('/quiz/single/{id}', 'QuizController@single')->name('admin.quiz.single');
    // Route::post('/quiz/image/positions', 'QuizController@img_positions')->name('admin.quiz.image.positions');
    // Route::get('/quiz/image/preview/{id}/{attr?}', 'QuizController@preview_pic')->name('admin.quiz.preview');
    // Route::post('/quiz/image/preview', 'QuizController@preview_pic_p')->name('admin.quiz.preview.post');
    
    // Route::get('/quiz/category', 'QuizController@category')->name('admin.category');
    // Route::post('/quiz/category/create', 'QuizController@category_create')->name('admin.category.create');
    // Route::get('/quiz/category/delete/{id}', 'QuizController@category_delete')->name('admin.category.delete');


});