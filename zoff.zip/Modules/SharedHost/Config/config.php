<?php

return [
    'name' => 'SharedHost'
];
