<?php

return [
    'name' => 'Accounts',
    'admin-routes' => [
    	(object)['r'=>url('/admin/accounts/all'), 'n' => 'All' ],
    ],
];
