<?php

namespace Modules\NewsAggr\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

use Modules\NewsAggr\Entities\Site;
use Modules\NewsAggr\Entities\Link;
use Socialite;
use \claviska\SimpleImage;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
// use Corcel\Model\Post as Post;
class NewsAggrController extends Controller
{
    // public function index(){
    // 	$posts = Post::published()->newest()->paginate(18, ['*'], 'news');
    // 	return view('newsaggr::news',['news' => $posts]);
    // }

    // public function single($slug){
    //     $other = Post::published()->newest()->paginate(18, ['*'], 'news');
    // 	$p = Post::where(['post_name'=> $slug])->get()[0];
    //     return view('newsaggr::news_single',['news' => $p,'others' => $other]);
    // }

    public function index(){
        $links = Link::where('active',1)->latest()->paginate(18, ['*'], 'links');
        return view('newsaggr::link', ['links'=> $links]);
    }
    public function api_latest(){
        $links = Link::latest()->paginate(18, ['*'], 'links');
        return response()->json($links);
    }
    public function refresh(){
        $sites = Site::where(['technology'=>'wordpress','api'=> true,'active'=>1])->get();
        foreach ($sites as $site) {
            if (!$json = @file_get_contents($site->url.'wp-json/wp/v2/posts?_embed')) {
                $site->active = 1;
                $site->save();
                $error = error_get_last();
                echo "HTTP request failed. Error was: " . $error['message'];
            } 
            echo($site->name);
            $obj = (array)json_decode($json); 
            foreach ($obj as $o) {
                if(Link::where(['site_id' => $site->id, 'api_id' => $o->id])->count() ==0){
                    $excerpt;
                    if(isset($o->_embedded->{'wp:featuredmedia'}[0]->source_url)){
                        $excerpt = $o->_embedded->{'wp:featuredmedia'}[0]->source_url;
                    }else{
                        $excerpt = "blank.png";
                    }
                    Link::create([
                         'title' => $o->title->rendered, 
                         'api_id' => $o->id, 
                         'img' => $excerpt,
                         'body' => substr($o->content->rendered,0,600),
                         'excerpt' => $o->excerpt->rendered,
                         'url' => $o->link,
                         'site_id' => $site->id
                    ]);    
                }
            }
        }
    }
}

