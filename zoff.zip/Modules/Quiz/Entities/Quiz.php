<?php

namespace Modules\Quiz\Entities;

use Illuminate\Database\Eloquent\Model;

class Quiz extends Model
{
    protected $table = 'quiz-quizzes';
    protected $fillable = [
        'title','picture','background','description','active','slug','choice',
        'avatar_x','avatar_y','avatar_w','avatar_h',
        'result_x','result_y','result_w','result_h',
        'avatar_text_x','avatar_text_y','avatar_text_w','avatar_text_h',
        'result_text_x','result_text_y','result_text_w','result_text_h',
    ];
    public function categories(){
        return $this->belongsToMany('Modules\Quiz\Entities\Category','quiz-category_quiz');
    }
}
