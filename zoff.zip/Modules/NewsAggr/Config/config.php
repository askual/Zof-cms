<?php

return [
    'name' => 'NewsAggr'
];
