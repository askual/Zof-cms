@extends('zof::layouts.admin')

@section('content')
<iframe src="/admin/filemanager" style="width: 100%; height: 500px; overflow: hidden; border: none;"></iframe>
@endsection