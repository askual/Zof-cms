<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateQuizzesTable extends Migration
{
    /**
     * Run the migrations.
     *'title','picture'
     * @return void
     */
    public function up()
    {
        Schema::create('quiz-quizzes', function (Blueprint $table) {
            $table->increments('id');
            $table->string('slug')->unique();
            $table->string('title');
            $table->string('picture');
            $table->string('background');
            $table->longText('choice');
            $table->text('description')->nullable();
            $table->boolean('active')->default(false);

            $table->integer('avatar_x')->default(53);
            $table->integer('avatar_y')->default(85);
            $table->integer('avatar_w')->default(250);
            $table->integer('avatar_h')->default(200);

            $table->integer('result_x')->default(453);
            $table->integer('result_y')->default(85);
            $table->integer('result_w')->default(250);
            $table->integer('result_h')->default(200);
            
            $table->integer('avatar_text_x')->default(50);
            $table->integer('avatar_text_y')->default(300);
            $table->integer('avatar_text_w')->default(30);
            $table->integer('avatar_text_h')->default(10);

            $table->integer('result_text_x')->default(500);
            $table->integer('result_text_y')->default(285);
            $table->integer('result_text_w')->default(30);
            $table->integer('result_text_h')->default(10);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('quiz-quizzes');
    }
}
