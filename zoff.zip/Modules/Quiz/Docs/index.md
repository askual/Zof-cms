# database
    Category    |   |africa, love, lifestyle
    Quiz        |title, pic, backgr, choice(array), 'description','active','slug', type, view
    Result      |quiz_id,user_id,pict,uuid
    Category_quiz| 
    