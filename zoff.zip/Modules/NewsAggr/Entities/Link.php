<?php

namespace Modules\NewsAggr\Entities;

use Illuminate\Database\Eloquent\Model;

class Link extends Model
{
    protected $table = 'newsaggr-links';

    protected $fillable = [
        'site_id', 'api_id','title', 'img', 'excerpt', 'url', 'point', 'view', 'body', 'active'
    ];

    public function site(){
        return $this->belongsTo('Modules\NewsAggr\Entities\Site');
    }
}
