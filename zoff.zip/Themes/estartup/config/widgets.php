<?php

$component_path = resource_path('views/theme2/components');
$widgets =  [
    (Object)['title'=>'blog' ,'name'=>'blog' , 'path'=>$component_path.'/blog.blade.php'],
    (Object)['title'=>'contact' ,'name'=>'contact' , 'path'=>$component_path.'/contact.blade.php'],
];