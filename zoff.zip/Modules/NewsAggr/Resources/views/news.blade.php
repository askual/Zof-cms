@extends('newsaggr::layouts.master')






@section('content')

<div class="row">
                <div class="col-sm-12 col-lg-12 col-md-12 section-title my-3">
                    <span class="up">Latest</span>
                    <span class="down">News</span>
                    <div class="line"></div>
                </div>
                <!-- news card -->
                @foreach($news as $n)
                <div class="news-card col-sm-12 col-md-4 col-lg-4">
                	<a href="{{route('news.single',['slug'=> $n->slug])}}">
                	@if($n->image)
                    <img src="{{$n->image}}" alt="news" class="img-fluid news-img">
                    @else
                    <img src="img/ph/2.jpg" alt="news" class="img-fluid news-img">
                    @endif
                    <div class="line"> </div>
                    <h5><a class="news-link">{{$n->post_title}}</a></h5>
                    <div class="date">
                        <p><i class="fa fa-calendar "></i> january 18 2018</p>
                    </div>
                	</a>
                </div>
                @endforeach


            </div>

@endsection



@section('js')
<script type="text/javascript">
  $( "#news" ).addClass( "active" );
</script>
@endsection