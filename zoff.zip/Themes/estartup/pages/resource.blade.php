@extends('estartup.layout')


@section('content')



<section class="padd-section wow fadeInUp">
    <div class="container">
      <div class="section-title text-center">
        <h2>ያውርዱ</h2>
        <p class="separator">አመታዊ ሪፖርቶችን፣ መተዳደሪያ ደንቡንና ሌሎችም ነገሮችን ያውርዱ</p>
      </div>
    </div>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-3 col-md-3 ">
            <ul style="font-size:120px">
                <li>መተዳደሪያ ደንቡ <a href="http://alenethiopia.org/files/1/አለን ኢትዮ (Aut.docx.pdf"><i class="fa fa-download"></i></a></li>
            </ul>
        </div>
    </div>
</div>
</section>



@endsection