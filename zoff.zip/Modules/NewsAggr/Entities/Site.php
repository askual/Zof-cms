<?php

namespace Modules\NewsAggr\Entities;

use Illuminate\Database\Eloquent\Model;

class Site extends Model
{
    protected $table = 'newsaggr-sites';
    protected $fillable = [
        'name', 'url','technology', 'api', 'point', 'active'
    ];
}
