<?php

namespace Modules\Quiz\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use App\Helpers\ModuleHelper;
use App\Helpers\MiscHelper;
use Modules\Zof\Entities\Option;

use Modules\Quiz\Entities\Quiz;
use Modules\Quiz\Entities\Category;
use Modules\Quiz\Entities\Result;

class AdminController extends Controller
{
    private $theme = "";
    public function __construct(){
		$this->middleware('isAdmin');
		$this->theme = Option::where('name','theme_current')->first()->value;
    }

    public function quiz(){
        $quiz = Quiz::all();
        return view('quiz::admin.all',['categories'=>Category::all(),'quiz'=>Quiz::latest()->get()]);
    }
    public function new_quiz(){
        return view('quiz::admin.quiz-create');
    }
    public function active_toogle($id){
        $q = Quiz::find($id);
        $q->active = !$q->active;
        $q->save();
        return redirect()->back();
    }


    public function quiz_single($id){
        $q = Quiz::find($id);
        return view('admin.quiz_single', ['quiz'=> $q]);
        return $q->title;
    }

    public function choice_delete(Request $request){
        $c = Choice::find($request['id']);
        Storage::delete('choice/'.$c->picture);
        $c->delete();
        $result = array('success' => true);
        return json_encode($result);
    }

    public function quiz_single_edit(Request $request){
        $q = Quiz::find($request['id']);
        $q->title = $request['title'];
        if($request->hasFile('picture')){
            $request->file('picture')
                        ->storeAs('public/quiz', $q->picture);
        }
        $q->save();
        return redirect()->back();
    }

    public function quiz_post(Request $request){
        $t  = $request['title'];
        $pp = Hash::make($t);
        $vowels = array(".", "/", "\\");
        $final = str_replace($vowels, "", $pp).".jpg";
        Quiz::create([
            'title' => $t,
            'picture' => $final
        ]);
        $path = $request->file('picture')
                        ->storeAs('public/quiz', $final);
        return redirect()->back();
    }
    public function choice_post(Request $request){
        $t  = $request['title'];
        $q  = $request['quiz_id'];
        $pp = Hash::make($q." = ".$t);
        // Provides: Hll Wrld f PHP
        $vowels = array(".", "/", "\\");
        $final = str_replace($vowels, "", $pp).".jpg";


        Choice::create([
            'title' => $t,
            'quiz_id' => $q,
            'picture' => $final
        ]);
        $path = $request->file('picture')
                        ->storeAs('public/choice', $final);
        return redirect()->back();
    }

    //admin.video.create.post

    
}