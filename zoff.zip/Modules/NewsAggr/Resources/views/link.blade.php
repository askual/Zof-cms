@extends('newsaggr::layouts.master')



@section('contents')
@verbatim
<div id="app">
  <!-- <b-container>
    <b-jumbotron header="Bootstrap Vue"
                 lead="Bootstrap 4 Components for Vue.js 2"
    >
      <p>For more information visit our website</p>
      <b-btn variant="primary" href="https://bootstrap-vue.js.org/">More Info</b-btn>
    </b-jumbotron>

    <b-form-group horizontal
                  :label-cols="4"
                  description="Let us know your name."
                  label="Enter your name"
    >
       <b-form-input v-model.trim="name"></b-form-input>
    </b-form-group>

    <b-alert variant="success" :show="showAlert">
      Hello {{ name }}
    </b-alert>
  </b-container> -->
  <b-card title="Card Title"
          img-src="https://picsum.photos/600/300/?image=25"
          img-alt="Image"
          img-top
          tag="article"
          style="max-width: 20rem;"
          class="mb-2">
    <p class="card-text">
      Some quick example text to build on the card title and make up the bulk of the card's content.
    </p>
    <b-button href="#" variant="primary">Go somewhere</b-button>
  </b-card>
</div>
@endverbatim
@endsection

@section('js3')
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/axios@0.18.0/index.min.js"></script>
<script>
      window.app = new Vue({
        el: "#app",
        data(){
          return {
              name: '',
              info: null
          }
        },
        computed: {
          showAlert() {
            return this.name.length > 4 ? true : false;
          }
        },
        mounted () {
            axios
              .get('https://news.askual.com/api/latest')
              .then(response => (this.info = response))
          }
      })
    </script>
@endsection



@section('content')
<div class="row">
	<div class="col-sm-12 col-lg-12 col-md-12 section-title my-3">
        <span class="up">Latest</span>
        <span class="down">Links</span>
        <div class="line"></div>
    </div>
    @foreach($links as $n)
    <div class="news-card col-sm-12 col-md-4 col-lg-4">
        <a href="{{$n->url}}" target="_blank">
        @if($n->img && $n->img!="blank.png")
        <img src="{{$n->img}}" alt="news" class="img-fluid news-img">
        @else
        <img src="/img/news.jpg" alt="news" class="img-fluid news-img">
        @endif
        <div class="line"> </div>
        <h5><a class="news-link"><?=$n->title?></a></h5>
        <div class="date">
            <p><i class="fa fa-calendar "></i>{{date('d-m-Y', strtotime($n->created_at))}} </p>
        </div>
        </a>
    </div>
    @endforeach
    {{ $links->links() }}
</div>
@endsection

@section('js')
<script type="text/javascript">
  $( "#link" ).addClass( "active" );
  $( "img" ).addClass( "img-fluid" );
</script>
@endsection