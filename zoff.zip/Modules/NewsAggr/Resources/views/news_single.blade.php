@extends('layouts.app')


@section('meta')
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="og:url"                content="{{route('news.single',['slug' => $news->slug ])}}" />
<meta property="og:type"               content="website" />
<meta property="og:title"              content="{{$news->title}}" />
<meta property="og:description"        content="{{$news->excerpt}}" />
<meta property="og:image"              content="{{$news->image}}" />

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.1&appId=190841044659032&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
@endsection



@section('content')

<div class="mt-4">
                <div class="row">
                    <div class="col-md-8 col-lg-8 col-sm-12">
                        <div class="news">
                            <div class="featured-img">
                                <img src="{{$news->image}}" class="img-fluid" alt="">
                            </div>

                            <div class="title mb-2">
                                <h5>{{$news->title}}</h5>
                            </div>
                            <div class="meta-data mb-3">
                                <!-- <div class="author-pic mr-2">
                                    <img src="img/greenish.png" alt="" class="rounded">
                                </div> -->
                                <div class="author-detail ">
                                    @foreach($news->terms['category'] as $category)
                                    <a href="#" class="name">{{$category}}</a>
                                    @endforeach
                                    <p class="date"><i class="fa fa-calender"></i> {{date('d-m-Y', strtotime($news->created_at))}}</p>
                                </div>
                            </div>

                            <div class="post">
                                <?= $news->content ?>
                                <!-- <div class="post-img">
                                    <img src="img/ph/2.jpg" alt="">
                                    <p class="caption">This is a picture </p>
                                </div>

                                <p>
                                    impedit placeat deleniti voluptatem animi omnis aliquid, eos, dolorem vero, praesentium tempore dolore. Rem nemo nam corporis ipsam itaque eaque quo iure eum eius aut neque dolorem voluptatem est esse vitae mollitia suscipit numquam labore voluptate aperiam,
                                    explicabo accusamus fugit. Est perferendis tempore soluta commodi quos quo!

                                </p> -->
                            </div>
                            <div class="blog-share d-flex mb-3 ">
                                <!-- <button class="btn mr-2 btn-primary"><i class="fa fa-heart mr-1"></i>Like <span class="badge">120</span></button> -->
                                <div class="fb-share-button"  data-size="large"
                                    data-href="{{route('news.single',['slug'=>$news->slug])}}" 
                                    data-layout="button_count">
                                </div>
                                <!-- <button class="btn mr-2 btn-twitter"><i class="fa fa-twitter mr-1"></i>አጋራ <span class="badge">12</span></button> -->
                            </div>
                            <!-- featured img -->
                        </div>
                    </div>
                    <div class="col-md-4 col-lg-4 col-sm-12">
                        <div class="section-title">

                            <span class="down">More News</span>
                            <div class="line"></div>
                        </div>

                        <div class="more-news">
                            @foreach($others as $n)
                            <div class="side-news">
                                <a style="text-decoration: none;" class="news-link" href="{{route('news.single',['slug'=>$n->slug])}}">
                                @if($n->image)
                                <img src="{{$n->image}}" alt="news">
                                @else
                                <img src="/img/news.jpg" alt="news">
                                @endif
                                <div class="side-news-card">
                                    <h5 style="text-decoration: none;">{{$n->post_title}}</a></h5>
                                    <div class="date">
                                        <p style="text-decoration: none;"><i class="fa fa-calendar "></i> {{date('d-m-Y', strtotime($n->created_at))}}</p>
                                    </div>

                                </div>
                                </a>
                            </div>
                            @endforeach
                        </div>

                        <!-- ads -->
                        <h3>Adverts</h3>
                    </div>
                </div>
            </div>


@endsection



@section('js')
<script type="text/javascript">
  $( "#news" ).addClass( "active" );
  $( "img" ).addClass( "img-fluid" );
</script>
@endsection