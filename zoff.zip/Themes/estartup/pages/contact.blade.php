@extends('estartup.layout')


@section('content')

@include('estartup.components.contact')
@endsection