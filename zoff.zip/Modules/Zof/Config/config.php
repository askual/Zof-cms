<?php

return [
    'name' => 'Zof'
];
