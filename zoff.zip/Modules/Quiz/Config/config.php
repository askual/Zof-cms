<?php

return [
    'name' => 'Quiz',
    'name-text' => 'Quiz',
    'version' => 0.1,
    'admin-routes' => [
    	(object)['r'=>url('/admin/quiz/new'), 'n' => 'New' ],
    	(object)['r'=>url('/admin/quiz/all'), 'n' => 'All' ],
    ],
];
