<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Http\Request;
$appRoutes = function()  {
	Route::get('/','NewsAggrController@index')->name('news.index');
	Route::get('/api/latest','NewsAggrController@api_latest')->name('news.api.latest');
	Route::get('/refresh','NewsAggrController@refresh')->name('refresh');
	//NEWS
	// Route::get('/news','NewsAggrController@index')->name('news');
	// Route::get('/news/{slug}','NewsAggrController@single')->name('news.single');

	// Route::get('/link','NewsAggrController@link')->name('link');
};

Route::group(array('domain' => 'news.askual.com'), $appRoutes);
Route::group(array('domain' => 'www.news.askual.com'), $appRoutes);

// Route::prefix('newsaggr')->group(function() {
//     Route::get('/', 'NewsAggrController@index');
// });
