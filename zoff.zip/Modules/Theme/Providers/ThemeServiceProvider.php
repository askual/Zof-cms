<?php

namespace Modules\Theme\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Illuminate\Database\Eloquent\Factory;

class ThemeServiceProvider extends ServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    protected $defer = false;

    /**
     * Boot the application events.
     *
     * @return void
     */
    public function boot()
    {
        Blade::directive('theme_img', function ($expression) {
            $theme = DB::table('zof-options')->where('name','theme_current')->get()[0]->value;
            return file_get_contents(base_path('Themes/'.$theme.'/img/'.$expression));
            return response(file_get_contents(base_path('Themes/'.$theme.'/img/'.$expression)), 200, [
                // 'Content-Type' => 'application/xml'
                'Content-Type' => 'image/png'
            ]);
            // $expression2 = substr($expression, 1,strlen($expression)-1);
            // $row_name = "themes_".$theme."_".$expression2;
            // if(isset(DB::table('zof-options')->where('name',substr($row_name,0,strlen($row_name)-1))->get()[0]->value )){
            //     return DB::table('zof-options')->where('name',substr($row_name,0,strlen($row_name)-1))->get()[0]->value;
            // }
            return $theme;
            // return '$theme error';
        });
        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        $this->registerFactories();
        $this->loadMigrationsFrom(__DIR__ . '/../Database/Migrations');
    }

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->register(RouteServiceProvider::class);
    }

    /**
     * Register config.
     *
     * @return void
     */
    protected function registerConfig()
    {
        $this->publishes([
            __DIR__.'/../Config/config.php' => config_path('theme.php'),
        ], 'config');
        $this->mergeConfigFrom(
            __DIR__.'/../Config/config.php', 'theme'
        );
    }

    /**
     * Register views.
     *
     * @return void
     */
    public function registerViews()
    {
        $viewPath = resource_path('views/modules/theme');

        $sourcePath = __DIR__.'/../Resources/views';

        $this->publishes([
            $sourcePath => $viewPath
        ],'views');

        $this->loadViewsFrom(array_merge(array_map(function ($path) {
            return $path . '/modules/theme';
        }, \Config::get('view.paths')), [$sourcePath]), 'theme');
    }

    /**
     * Register translations.
     *
     * @return void
     */
    public function registerTranslations()
    {
        $langPath = resource_path('lang/modules/theme');

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, 'theme');
        } else {
            $this->loadTranslationsFrom(__DIR__ .'/../Resources/lang', 'theme');
        }
    }

    /**
     * Register an additional directory of factories.
     * 
     * @return void
     */
    public function registerFactories()
    {
        if (! app()->environment('production')) {
            app(Factory::class)->load(__DIR__ . '/../Database/factories');
        }
    }

    /**
     * Get the services provided by the provider.
     *
     * @return array
     */
    public function provides()
    {
        return [];
    }
}
