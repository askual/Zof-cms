<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLinksTable extends Migration
{
    /**
     * Run the migrations.
     * 'site_id', 'api_id','title', 'img', 'excerpt', 'url', 'point', 'view', 'body', 'active'
     * @return void
     */
    public function up()
    {
        Schema::create('newsaggr-links', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('site_id')->unsigned();
            $table->integer('api_id');
            $table->string('title');
            $table->string('img');
            $table->string('excerpt')->nullable();
            $table->longText('body')->nullable();
            $table->string('url');
            $table->integer('point')->default(500);
            $table->integer('view')->default(0);
            $table->boolean('active')->default(false);
            $table->timestamps();

            $table->foreign('site_id')->references('id')->on('newsaggr-sites');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('newsaggr-links');
    }
}
