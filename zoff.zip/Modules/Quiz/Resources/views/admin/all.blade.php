@extends('layouts.admin')

@section('css')
<link href="{{ url('adminlte/plugins/datatables/dataTables.bootstrap.min.css') }}" rel="stylesheet">
<link href="{{ url('bower_components/select2/dist/css/select2.min.css') }}" rel="stylesheet">

@endsection




@section('content')

    <section class="content-header">
      <h1>
        Quiz
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Quiz</li>
      </ol>    
    </section>
    <br>
    <div class="nav-tabs-custom">
      <ul class="nav nav-tabs pull-right">
        <li class="pull-left header"><i class="fa fa-th"></i> Quiz List</li>
      </ul>
      <div class="tab-content">
        <table id="UsersTable" class="table table-bordered table-striped">
          <thead>
            <tr>
            <th>title</th>
            <th>question</th>
            <th>description</th>
            <th>picture</th>
            <th>active</th>
            <th>Choices</th>
            <th>tags</th>
            </tr>
          </thead>
          <tbody>
            @foreach($quiz as $q)
            <tr>
              <td>{{$q->title}} <br><a href="{{route('admin.quiz.single',['id'=> $q->id])}}" class="btn btn-success">Detail</a>  </td>
              <td>{{$q->question}}</td>
              <td>{{$q->description}}</td>
              <td><img height="100px" src="{{url('/quiz/mainpic/'.$q->picture)}}"></td>
              <td>{{$q->active}} <br> <a href="{{route('admin.quiz.active_toggle',['id'=> $q->id])}}" class="btn btn-success">Toggle</a>  </td>
              <td>{{$q->choices()->count()}}</td>
              <td>
                <form enctype="multipart/form-data" action="{{route('admin.quiz.tag')}}" method="POST">
                  {{ csrf_field() }}
                  <input type="number" name="id" value="{{$q->id}}" hidden>
                  <select class="form-control select2" multiple="multiple" data-placeholder="Select a State"
                          style="width: 100%;" name="tags[]">
                          @foreach($categories as $c)
                          <option value="{{$c->id}}">{{$c->title}}</option>
                          @endforeach

                          @foreach($q->categories as $c)
                          <option value="{{$c->id}}" selected>{{$c->title}}</option>
                          @endforeach
                          
                  </select>
                  <button class="btn btn-success" type="submit">Update</button>
                </form>
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    </div>


    

@endsection






@section('js')<script src="{{ url('bower_components/select2/dist/js/select2.full.min.js') }}"></script>

<script src="{{ url('adminlte/plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ url('adminlte/plugins/datatables/dataTables.bootstrap.min.js') }}"></script>
<script src="{{ url('adminlte/plugins/datatables/dataTables.buttons.min.js') }}"></script>
<script src="{{ url('adminlte/plugins/datatables/dataTables.select.min.js') }}"></script>
<script src="{{ url('adminlte/plugins/datatables/dataTables.editor.min.js') }}"></script>
<script>
  $(function () {        
    $('.select2').select2()
    $('#UsersTable').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true
    })
    $('#InstTable').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true
    })
  })
</script>

<script type="text/javascript">
  $( "#quiz" ).addClass( "active" );
  $( "#quiz-All" ).addClass( "active" );
</script>
@endsection