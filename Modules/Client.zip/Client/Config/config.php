<?php

return [
    'name' => 'Client',
    'admin-routes' => [
    	(object)['r'=>url('/admin/client/add'), 'n' => 'Add' ],
    ],
];
