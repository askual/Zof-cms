<?php

namespace Modules\Quiz\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;
use \claviska\SimpleImage;

class QuizController extends Controller
{
    public function abcd(){
        // $this->abcd2();
        $this->dd();
        // $this->abcd1();
    }
    public function dd(){
        $image = new SimpleImage();
        $avatar = new SimpleImage();
        $answer = new SimpleImage();
        $name_options = array(
          'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
          'anchor' => 'top left','xOffset' => 85,'yOffset' =>255,'shadow' => null
          );
          $year_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 85,'yOffset' =>357,'shadow' => null
          );
          $date_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 245,'yOffset' =>357,'shadow' => null
          );
          $sex_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 245,'yOffset' =>306,'shadow' => null
          );
          $id_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 85,'yOffset' =>306,'shadow' => null
          );
        $string = file_get_contents(public_path("Scripts/dev.json"));
        $json_a = json_decode($string, true);
        foreach ($json_a as $key => $value) {
          $namee = $value['NAME'];
          $yearr = $value['Year'];
          $datee = "17/02/19";
          $idnoo = "";
          $img_name = $value["No."].".jpg";
          $answer
              ->fromFile(public_path("Pics/devs/".$img_name))
              ->resize(150, 130)  
              // ->bestFit(250,300)
              ->border('black', 0);
          $avatar
            ->fromFile(public_path('kkk.jpg'))
            ->text($namee,$name_options)
            ->text($yearr,$year_options)
            ->text($idnoo,$id_options)
            ->text("Male",$sex_options)
            ->text($datee,$date_options)
            // ->border('black', 4)
            ->overlay($answer, 'top left', 2 , 87  , 112)
          //   ->toScreen();
            ->toFile(public_path('temp2/d'.$value['No.'].'.jpg'));
            break;
          }
      return $namee;
      }
      public function abcd1(){
        $image = new SimpleImage();
        $avatar = new SimpleImage();
        $answer = new SimpleImage();
        $name_options = array(
          'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
          'anchor' => 'top left','xOffset' => 85,'yOffset' =>255,'shadow' => null
          );
          $year_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 85,'yOffset' =>357,'shadow' => null
          );
          $date_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 245,'yOffset' =>357,'shadow' => null
          );
          $sex_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 245,'yOffset' =>306,'shadow' => null
          );
          $id_options = array(
              'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
              'anchor' => 'top left','xOffset' => 85,'yOffset' =>306,'shadow' => null
          );
        $string = file_get_contents(public_path("Scripts/div2.json"));
        $json_a = json_decode($string, true);
        foreach ($json_a as $key => $value) {
            $namee = $value['Name'];
          $yearr = $value['Year'];
        //   $idnoo = $value['E-Mail'];
          $idnoo = "";
          $phonee = $value['Phone'];
          $datee = "17/02/19";
          $img_name = strtolower(str_replace(" ", "", $phonee));

        //   $namee = $value['NAME'];
        //   $yearr = $value['Year'];
        //   $idnoo = "";
        //   $img_name = $value["No."].".jpg";
        $sexx = "Male";
        if($namee=="Mebatsion Sahle"){
            $sexx = "Female";
        }
          $answer
              ->fromFile(public_path("Pics/div1/".$img_name.".jpg"))
              ->resize(150, 130)  
              // ->bestFit(250,300)
              ->border('black', 0);
          $avatar
            ->fromFile(public_path('kkk.jpg'))
            ->text($namee,$name_options)
            ->text($yearr,$year_options)
            ->text($idnoo,$id_options)
            ->text($sexx,$sex_options)
            ->text($datee,$date_options)
            // ->border('black', 4)
            ->overlay($answer, 'top left', 2 , 87  , 112)
          //   ->toScreen();
            ->toFile(public_path('temp2/dd'.$img_name.'.jpg'));
          }
      return $namee;
      }

    public function abcd2(){

      $image = new SimpleImage();
      $avatar = new SimpleImage();
      $answer = new SimpleImage();
      $name_options = array(
        'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
        'anchor' => 'top left','xOffset' => 85,'yOffset' =>255,'shadow' => null
        );
        $year_options = array(
            'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
            'anchor' => 'top left','xOffset' => 85,'yOffset' =>357,'shadow' => null
        );
        $date_options = array(
            'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
            'anchor' => 'top left','xOffset' => 245,'yOffset' =>357,'shadow' => null
        );
        $sex_options = array(
            'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
            'anchor' => 'top left','xOffset' => 245,'yOffset' =>306,'shadow' => null
        );
        $id_options = array(
            'fontFile' => public_path('fonts/Oswald-Regular.ttf'), 'size' => 18, 'color' => 'white',
            'anchor' => 'top left','xOffset' => 85,'yOffset' =>306,'shadow' => null
        );
      $string = file_get_contents(public_path("Scripts/div1.json"));
      $json_a = json_decode($string, true);
      foreach ($json_a as $key => $value) {
        $namee = $value['NAME'];
        $yearr = $value['Year'];
        $datee = "17/02/19";
        $idnoo = $value['ID No.'];
        $img_name = strtolower(str_replace("/", "_", $idnoo));
        $answer
            ->fromFile(public_path("Pics/div2/".$img_name.".jpg"))
            ->resize(150, 130)  
            // ->bestFit(250,300)
            ->border('black', 0);
        $avatar
          ->fromFile(public_path('finall'))
          ->text($namee,$name_options)
          ->text($yearr,$year_options)
          ->text($idnoo,$id_options)
          ->text("Male",$sex_options)
          ->text($datee,$date_options)
          // ->border('black', 4)
          ->overlay($answer, 'top left', 2 , 87  , 112)
        //   ->toScreen();
          ->toFile(public_path('temp2/'.$value['No.'].'.jpg'));
        }
    return $namee;
    }
    public function play($slug){
        $q = Quiz::where(['slug'=>$slug])->firstOrFail();
        $fb_id = Auth::user()->accounts()->get()[0]->provider_id;
        $choice = $q->choices()->get()->random();
        $url = 'http://graph.facebook.com/'.$fb_id.'/picture?height=200';
        $contents = file_get_contents($url);
        $f = Storage::put('avatars/'.$fb_id.'.jpg', $contents);
        $options = array(
            'fontFile' => '/home/tfozo/public_html/fonts/yebse.ttf', 'size' => 28, 'color' => 'black',
            'anchor' => 'top left','xOffset' => 50,'yOffset' => 300,'shadow' => null);
        $optionsTwo = array(
            'fontFile' => '/home/tfozo/public_html/fonts/yebse.ttf','size' => 43,'color' => 'black',
            'anchor' => 'top left','xOffset' => 500,'yOffset' => 285,'shadow' => null);
        $image = new SimpleImage();
        $avatar = new SimpleImage();
        $answer = new SimpleImage();
        $avatar
            ->fromFile('/home/tfozo/laravel/storage/app/avatars/'.$fb_id.'.jpg')
            ->bestFit(250,200)
            ->border('black', 4);
        $answer
            ->fromFile('/home/tfozo/laravel/storage/app/public/choice/'.$choice->picture)
            ->bestFit(250,200)
            ->border('black', 4);
        $theimage = $image
          ->fromFile('/home/tfozo/laravel/storage/app/public/quiz/'.$q->picture)
          ->autoOrient()             // adjust orientation based on exif data
          ->bestFit(800, 420)        // proportinoally resize to fit inside a 250x400 box
          ->overlay($avatar, 'top left', 1 , 53 , 85) // add a watermark image
          ->overlay($answer, 'top left', 1 , 453 , 85) // add a watermark image
          ->text(Auth::user()->name,$options)
          ->text($choice->title,$optionsTwo)
          ->toFile('/home/tfozo/laravel/storage/app/results/one.jpg', 'image/jpeg')
          // ->toFile('results/'.$fb_id.$id.$choice->id.'.jpg', 'image/jpeg')
          ->toScreen();              // output to the screen
          // Storage::put('results/'.$fb_id.'.jpg', $theimage);
        // return view('quiz_result',[
        //     'ans_pic' => 'results/'.$fb_id.$id.$choice->id.'.jpg',
        //     'title' => $q->title,
        //     'the_id' => $id
        // ]);
    }
}
