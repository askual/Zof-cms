<?php

namespace Modules\Quiz\Entities;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'quiz-categories';
    protected $fillable = [
        'name', 'slug'
    ];

    public function quizzes(){
    	return $this->belongsToMany('Modules\Quiz\Entities\Quiz','quiz-category_quiz');
    }
}
